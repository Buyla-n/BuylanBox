package com.buyla.application.ui.screen

import android.annotation.SuppressLint
import android.content.Context
import android.os.Build
import android.system.Os
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import java.io.BufferedReader
import java.io.InputStreamReader

object Info {

    @SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
    @OptIn(ExperimentalMaterial3Api::class)
    @Composable
    fun InfoScreen() {
        val context = LocalContext.current
        val infos = remember {
            listOf(
                InfoItem("机型代号", Build.DEVICE),
                InfoItem("安卓版本", Build.VERSION.RELEASE ?: "未知"),
                InfoItem("系统指纹", Build.FINGERPRINT),
                InfoItem("内核版本", Os.uname().release),
                InfoItem("SE Linux 状态", getSELinuxStatus()),
                InfoItem("分区格式", getPartitionFormat()),
                InfoItem("动态分区状态", getDynamicPartitionStatus()),
                InfoItem("CPU 架构", Build.SUPPORTED_ABIS.firstOrNull() ?: "未知"),
                InfoItem("应用版本", getAppVersion(context)),
                InfoItem("制造商", Build.MANUFACTURER),
            )
        }

        Scaffold(
            topBar = {
                CenterAlignedTopAppBar(
                    title = { Text(text = "信息", modifier = Modifier
                        .fillMaxWidth()
                        .padding(start = 8.dp),style = MaterialTheme.typography.titleLarge) },
                )
            },
        ){ innerPadding ->
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                items(infos) { info ->
                    InfoCard(info)
                }
            }
        }
    }

    @Composable
    fun InfoCard(info: InfoItem) {
        Column(
            modifier = Modifier
                .padding(horizontal = 16.dp, vertical = 8.dp)
                .fillMaxWidth()
                //.height(64.dp)
                .background(
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    shape = RoundedCornerShape(8.dp)
                )
                .border(
                    width = 1.dp,
                    color = MaterialTheme.colorScheme.outline,
                    shape = RoundedCornerShape(8.dp)
                )
                .clickable { }, // 添加点击事件
        ) {
            Text(
                text = info.title,
                style = MaterialTheme.typography.bodyLarge,
                modifier = Modifier
                    .padding(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 0.dp)
            )
            Text(
                text = info.status,
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier
                    .padding(start = 16.dp, end = 16.dp, top = 0.dp, bottom = 8.dp)
            )
        }
    }

    private fun getSELinuxStatus(): String {
        return try {
            val enforced = android.os.StrictMode.VmPolicy.Builder().build() != null
            if (enforced) "强制" else "关闭 / 宽容"
        } catch (e: Exception) {
            "未知"
        }
    }

    private fun getPartitionFormat(): String {
        return when {
            isABEnabled() -> "AB / VAB"
            else -> "Only A"
        }
    }

    private fun getDynamicPartitionStatus(): String {
        val result = executeCommand("getprop ro.boot.dynamic_partitions")
        if (result == "true") {
            return "启用"
        } else {
            return "关闭"
        }
    }

    private fun getAppVersion(context: Context): String {
        return try {
            val packageInfo = context.packageManager.getPackageInfo(context.packageName, 0)
            packageInfo.versionName ?: "未知"
        } catch (e: Exception) {
            "未知"
        }
    }

    data class InfoItem(
        val title: String,  // 信息标题
        val status: String, // 信息状态
        //val icon: Int       // 图标资源 ID
    )

    private fun isABEnabled(): Boolean {
        val result = executeCommand("getprop ro.build.ab_update")
        return result == "true"
    }

    fun executeCommand(command: String): String {
        return try {
            val process = Runtime.getRuntime().exec(command)
            val reader = BufferedReader(InputStreamReader(process.inputStream))
            val result = reader.readText().trim()
            reader.close()
            process.waitFor()
            result
        } catch (e: Exception) {
            "Error: ${e.message}"
        }
    }

}