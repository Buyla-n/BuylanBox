package com.buyla.application

import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.cardview.widget.CardView
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.vectorResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.buyla.application.ui.theme.MyAppTheme

class AppsListActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        enableEdgeToEdge()
        window.isNavigationBarContrastEnforced = false

        val packageName = intent.getStringExtra("packageName") ?: return

        setContent {
            MyAppTheme {
                AppActivitiesList(packageName)
            }
        }
    }

    @OptIn(ExperimentalMaterial3Api::class)
    @Composable
    private fun AppActivitiesList(packageName: String) {
        val packageManager = packageManager
        val packageInfo = packageManager.getPackageInfo(packageName, PackageManager.GET_ACTIVITIES)
        val activities = packageInfo.activities?.toList() ?: emptyList()

        Scaffold(
            topBar = {
                CenterAlignedTopAppBar(
                    navigationIcon = {
                        IconButton(onClick = { finish() }) {
                            Icon(
                                imageVector = ImageVector.vectorResource(id = R.drawable.baseline_arrow_back_24),
                                contentDescription = "返回"
                            )
                        }
                    },
                    title = {
                        Text(
                            text = "活动列表",
                            //modifier = Modifier.fillMaxWidth().padding(start = 8.dp),
                            style = MaterialTheme.typography.titleLarge
                        )
                    }
                )
            }
        ) { innerPadding ->
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                items(activities) { activityInfo ->
                    val isExportable = activityInfo.exported
                    val context = LocalContext.current
                    ActivityListItem(appInfo = activityInfo, context = context, exp = isExportable)
                }
            }
        }
    }

    @Composable
    private fun ActivityListItem(appInfo: ActivityInfo, context: Context, exp: Boolean) {
        var showWarningDialog by remember { mutableStateOf(false) }
        Row(
            modifier = Modifier
                .padding(horizontal = 16.dp, vertical = 8.dp)
                .fillMaxWidth()
                .height(72.dp)
                .background(
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    shape = RoundedCornerShape(8.dp)
                )
                .border(
                    width = 1.dp,
                    color = MaterialTheme.colorScheme.outline,
                    shape = RoundedCornerShape(8.dp)
                )
                .clickable { }, // 添加点击事件
            verticalAlignment = Alignment.CenterVertically
        ) {
            // 应用图标
            AndroidView(
                factory = { ctx ->
                    // 使用 CardView 作为容器
                    CardView(ctx).apply {
                        layoutParams = ViewGroup.LayoutParams(
                            ViewGroup.LayoutParams.WRAP_CONTENT,
                            ViewGroup.LayoutParams.WRAP_CONTENT
                        )
                        radius = 16.0F // 设置圆角半径
                        addView(ImageView(ctx).apply {
                            layoutParams = ViewGroup.LayoutParams(
                                ViewGroup.LayoutParams.MATCH_PARENT,
                                ViewGroup.LayoutParams.MATCH_PARENT
                            )
                            scaleType = ImageView.ScaleType.FIT_CENTER
                        })
                    }
                },
                update = { cardView ->
                    val imageView = cardView.getChildAt(0) as ImageView
                    imageView.setImageDrawable(
                        context.packageManager.getApplicationIcon(appInfo.packageName)
                    )
                },
                modifier = Modifier
                    .size(48.dp)
                    .padding(8.dp)
            )

            Column(modifier = Modifier.weight(0.8f)) {
                // 应用名称
                Text(
                    text = appInfo.loadLabel(context.packageManager).toString(),
                    style = MaterialTheme.typography.bodyLarge,
                    modifier = Modifier
                        .padding(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 0.dp)
                )

                Text(
                    text = appInfo.name.toString().take(38),
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier
                        .padding(start = 16.dp, end = 16.dp, top = 0.dp, bottom = 8.dp)
                )
            }

            if (!exp) {
                IconButton(onClick = { showWarningDialog = true }) {
                    Icon(
                        imageVector = ImageVector.vectorResource(id = R.drawable.round_warning_24),
                        contentDescription = "未导出"
                    )
                }
                if (showWarningDialog){
                    AlertDialog(
                        onDismissRequest = { showWarningDialog = false },
                        title = { Text("未导出的 Activity") },
                        text = {
                            Text("Android未导出的Activity指未在AndroidManifest.xml中设置 android:exported= true 的组件,默认不可被外部应用访问,仅限应用内部使用,提升安全性,打开这类 Activity 需要根权限")
                        },
                        confirmButton = {
                            TextButton(onClick = { showWarningDialog = false }) {
                                Text("确定")
                            }
                        },
                        dismissButton = {
                            TextButton(onClick = { showWarningDialog = false }) {
                                Text("取消")
                            }
                        }
                    )
                }
            }

            Button(
                onClick = {
                    if (exp) {
                        val packageName = appInfo.packageName  // 目标应用的包名
                        val className = appInfo.name  // 目标 Activity 的完整类名

                        val intent = Intent().apply {
                            setClassName(packageName, className)
                        }

                        try {
                            startActivity(intent)
                        } catch (e: Exception) {
                            // 如果目标 Activity 不存在或无法启动
                            Toast.makeText(
                                this@AppsListActivity,
                                "无法启动目标应用",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    } else {
                        Toast.makeText(
                            this@AppsListActivity,
                            "Activity 未导出",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                },
                modifier = Modifier.padding(8.dp),
                shape = RoundedCornerShape(16.dp),
            ) {
                Text("打开")
            }
        }
    }
}