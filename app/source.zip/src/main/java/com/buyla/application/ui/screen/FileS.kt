package com.buyla.application.ui.screen
    
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.vectorResource
import androidx.compose.ui.unit.dp
import com.buyla.application.R
import com.buyla.application.ui.util.FileUtil.HandleFileClick
import com.buyla.application.ui.util.FileUtil.fileList
import com.buyla.application.ui.util.FileUtil.getFileIconAndType
import java.nio.file.Path
import java.nio.file.Paths

object FileS {
        @SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
        @OptIn(ExperimentalMaterial3Api::class)
        @Composable
        fun FileScreen(context: Context) {
            var leftPath by remember { mutableStateOf(Paths.get("/sdcard")) }
            var rightPath by remember { mutableStateOf(Paths.get("/sdcard")) }
            var sortByName by remember { mutableStateOf(true) }
            var folderFirst by remember { mutableStateOf(true) }
            var showSortDialog by remember { mutableStateOf(false) }
    
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R && !Environment.isExternalStorageManager()) {
                val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION)
                intent.data = Uri.parse("package:" + context.packageName)
                context.startActivity(intent)
            }
    
            Scaffold(
                topBar = {
                    CenterAlignedTopAppBar(
                        title = { Text(text = "文件", modifier = Modifier
                            .fillMaxWidth()
                            .padding(start = 8.dp),style = MaterialTheme.typography.titleLarge) },
                        actions = {
                            IconButton(onClick = { showSortDialog = true }) {
                                Icon(
                                    imageVector = ImageVector.vectorResource(id = R.drawable.baseline_menu_24),
                                    contentDescription = "Sort Files"
                                )
                            }
                        }
                    )
                },
            ) { innerPadding ->
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                ) {
                    // 左侧文件列表
                    LazyColumn(
                        modifier = Modifier.weight(1f)
                    ) {
                        item {
                            fileList(ImageVector.vectorResource(id = R.drawable.baseline_arrow_upward_24), "..", onClick = {
                                // 处理返回上一级
                                val parentPath = leftPath.parent
                                if (parentPath != null) leftPath = parentPath
                            },  type = "..", filePath = leftPath, OppPath = leftPath, isLeft = true)
                        }
                        items(getSortedFiles(leftPath, sortByName, folderFirst)) { file ->
                            val filePath = leftPath.resolve(file)
                            val (icon, type) = getFileIconAndType(filePath.toString())
                            fileList(icon, file, onClick = {
                                // 使用 handleFileClick 函数处理点击事件
                                HandleFileClick(
                                    context = context,
                                    filePath = filePath,
                                    type = type
                                ) { newPath ->
                                    leftPath = newPath // 更新路径，进入文件夹
                                }
                            },  type = type, filePath = filePath, OppPath = rightPath, isLeft = true)
                        }
                    }
    
                    Box(
                        modifier = Modifier
                            .width(1.dp) // 分割线宽度
                            .fillMaxHeight() // 高度与父组件一致
                            .background(color = MaterialTheme.colorScheme.outline) // 使用淡色
                    )
    
                    // 右侧文件列表
                    LazyColumn(
                        modifier = Modifier.weight(1f)
                    ) {
                        item {
                            fileList(ImageVector.vectorResource(id = R.drawable.baseline_arrow_upward_24), "..", onClick = {
                                // 处理返回上一级
                                val parentPath = rightPath.parent
                                if (parentPath != null) rightPath = parentPath
                            },  type = "..", filePath = leftPath, OppPath = leftPath, isLeft = false)
                        }
                        items(getSortedFiles(rightPath, sortByName, folderFirst)) { file ->
                            val filePath = rightPath.resolve(file)
                            val (icon, type) = getFileIconAndType(filePath.toString())
                            fileList(icon, file, onClick = {
                                // 使用 handleFileClick 函数处理点击事件
                                HandleFileClick(
                                    context = context,
                                    filePath = filePath,
                                    type = type
                                ) { newPath ->
                                    rightPath = newPath // 更新路径，进入文件夹
                                }
                            }, type = type, filePath = filePath, OppPath = leftPath, isLeft = false)
                        }
                    }
                }
            }

            // 弹出排序对话框
            if (showSortDialog) {
                AlertDialog(
                    onDismissRequest = { showSortDialog = false },
                    title = { Text("排序设置") },
                    text = {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Checkbox(
                                    checked = sortByName,
                                    onCheckedChange = { sortByName = it }
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("按名称排序")
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Checkbox(
                                    checked = folderFirst,
                                    onCheckedChange = { folderFirst = it }
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("文件夹优先")
                            }
                        }
                    },
                    confirmButton = {
                        TextButton(onClick = { showSortDialog = false }) {
                            Text("确定")
                        }
                    },
                    dismissButton = {
                        TextButton(onClick = { showSortDialog = false }) {
                            Text("取消")
                        }
                    }
                )
            }
        }

        // 获取文件列表并排序
        fun getSortedFiles(path: Path, sortByName: Boolean, folderFirst: Boolean): List<String> {
            return try {
                val files = path.toFile().listFiles()?.toList() ?: emptyList()
                files.sortedWith(compareBy(
                    { if (folderFirst) !it.isDirectory else false },
                    { if (sortByName) it.name.lowercase() else it.name }
                )).map { it.name }
            } catch (e: Exception) {
                emptyList()
            }
        }


    }

