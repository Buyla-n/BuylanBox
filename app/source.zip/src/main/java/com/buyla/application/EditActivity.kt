package com.buyla.application

import android.Manifest
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.vectorResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.buyla.application.ui.theme.MyAppTheme
import java.io.File

class EditActivity : ComponentActivity() {
    private lateinit var filePath: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        enableEdgeToEdge()
        window.isNavigationBarContrastEnforced = false

        // 获取传递过来的文件路径
        filePath = intent.getStringExtra("filePath") ?: run {
            finish() // 如果没有文件路径，直接关闭Activity
            return
        }

        // 注册权限请求
        val requestPermissionLauncher = registerForActivityResult(
            ActivityResultContracts.RequestPermission()
        ) { isGranted ->
            if (isGranted) {
                loadFileContent()
            } else {
                Toast.makeText(this, "需要存储权限才能打开文件", Toast.LENGTH_SHORT).show()
                finish()
            }
        }

        // 检查权限
        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.READ_EXTERNAL_STORAGE
            ) != android.content.pm.PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissionLauncher.launch(Manifest.permission.READ_EXTERNAL_STORAGE)
        } else {
            loadFileContent()
        }
    }

    private fun loadFileContent() {
        val file = File(filePath)
        if (file.exists()) {
            val content = file.readText()
            setContent {
                MyAppTheme {
                    EditScreen(filePath, content)
                }
            }
        } else {
            Toast.makeText(this, "文件不存在！", Toast.LENGTH_SHORT).show()
            finish()
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditScreen(filePath: String, fileContent: String) {
    var text by remember { mutableStateOf(TextFieldValue(fileContent)) }
    var originalContent by remember { mutableStateOf(fileContent) }
    var showExitDialog by remember { mutableStateOf(false) }
    var isAutoSaveEnabled by remember { mutableStateOf(false) }
    val context = LocalContext.current

    // 撤回和重做功能
    val undoStack = remember { mutableStateListOf<String>() }
    val redoStack = remember { mutableStateListOf<String>() }

    // 处理全面屏手势退出
    BackHandler(onBack = {
        if (text.text != originalContent) {
            showExitDialog = true
        } else {
            (context as? ComponentActivity)?.finish()
        }
    })

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Start
                    ) {
                        // 添加一个按钮（例如返回按钮）
                        IconButton(onClick = {
                            if (text.text != originalContent) {
                                showExitDialog = true
                            } else {
                                (context as? ComponentActivity)?.finish()
                            }
                        }) {
                            Icon(
                                imageVector = ImageVector.vectorResource(id = R.drawable.baseline_arrow_back_24),
                                contentDescription = "返回"
                            )
                        }

                        // 添加标题
                        Text(
                            text = "文本编辑",
                            modifier = Modifier.padding(start = 8.dp) // 为标题添加一些间距
                        )
                    }
                },
                actions = {
                    // 撤回按钮
                    IconButton(onClick = {
                        val lastContent = undoStack.removeLast()
                        redoStack.add(text.text)
                        text = TextFieldValue(lastContent)
                    },
                        enabled = undoStack.isNotEmpty(),) {
                        Icon(
                            imageVector = ImageVector.vectorResource(id = R.drawable.baseline_undo_24),
                            contentDescription = "Undo"
                        )
                    }
                    // 重做按钮
                    IconButton(onClick = {
                        val lastContent = redoStack.removeLast()
                        undoStack.add(text.text)
                        text = TextFieldValue(lastContent)
                    },
                        enabled = redoStack.isNotEmpty(),) {
                        Icon(
                            imageVector = ImageVector.vectorResource(id = R.drawable.baseline_redo_24),
                            contentDescription = "Redo"
                        )
                    }
                    // 保存按钮
                    IconButton(
                        onClick = {
                            saveFileContent(filePath, text.text)
                            Toast.makeText(context, "文件已保存", Toast.LENGTH_SHORT).show()
                            originalContent = text.text
                            undoStack.clear()
                            redoStack.clear()
                        }
                    ) {
                        Icon(
                            imageVector = ImageVector.vectorResource(id = R.drawable.baseline_save_24),
                            contentDescription = "Save"
                        )
                    }

                    // 菜单按钮
                    var expanded by remember { mutableStateOf(false) }
                    IconButton(onClick = { expanded = true }) {
                        Icon(
                            imageVector = ImageVector.vectorResource(id = R.drawable.baseline_menu_24),
                            contentDescription = "Menu"
                        )
                    }
                    DropdownMenu(
                        expanded = expanded,
                        onDismissRequest = { expanded = false }
                    ) {
                        DropdownMenuItem(
                            text = { Text("自动保存") },
                            onClick = {
                                isAutoSaveEnabled = !isAutoSaveEnabled
                                expanded = false
                            },
                            leadingIcon = {
                                Icon(
                                    imageVector = if (isAutoSaveEnabled) ImageVector.vectorResource(id = R.drawable.baseline_check_box_24) else ImageVector.vectorResource(id = R.drawable.baseline_check_box_outline_blank_24),
                                    contentDescription = "AutoSave"
                                )
                            }
                        )
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            var textSize by remember { mutableStateOf(16.sp) } // 默认文字大小
            BasicTextField(
                value = text,
                onValueChange = {
                    if (isAutoSaveEnabled) {
                        saveFileContent(filePath, it.text)
                    }
                    if (text.text != it.text) {
                        undoStack.add(text.text)
                        redoStack.clear()
                    }
                    text = it
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .padding(16.dp)
                    .pointerInput(Unit) {
                        detectTransformGestures { _, _, zoom, _ ->
                            // 双指捏合手势调整字体大小
                            textSize = (textSize.value * zoom).coerceIn(1f, 64f).sp
                        }
                    }
                    .pointerInput(Unit) {
                        detectTapGestures(onPress = {
                            // 阻止单指滑动影响捏合操作
                            awaitRelease()
                        })
                    },
                keyboardOptions = KeyboardOptions.Default,
                keyboardActions = KeyboardActions.Default,
                singleLine = false,
                decorationBox = { innerTextField ->
                    if (text.text.isEmpty()) {
                        Text(
                            text = "请输入内容...",
                            style = MaterialTheme.typography.bodyMedium.copy(fontSize = textSize),
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                        )
                    }
                    innerTextField()
                },
                textStyle = TextStyle(fontSize = textSize) // 动态设置字体大小
            )
        }
    }

    // 弹出退出确认对话框
    if (showExitDialog) {
        ExitDialog(
            onConfirm = {
                saveFileContent(filePath, text.text)
                (context as? ComponentActivity)?.finish()
            },
            onCancel = {
                showExitDialog = false
            },
            onExitWithoutSave = {
                (context as? ComponentActivity)?.finish()
            }
        )
    }
}

@Composable
fun ExitDialog(
    onConfirm: () -> Unit,
    onCancel: () -> Unit,
    onExitWithoutSave: () -> Unit
) {
    AlertDialog(
        onDismissRequest = { /* Do nothing */ },
        title = { Text("确认操作") },
        text = { Text("是否保存更改并退出？") },
        confirmButton = {
            TextButton(onClick = onConfirm) {
                Text("保存并退出")
            }
        },
        dismissButton = {
            TextButton(onClick = onCancel) {
                Text("取消")
            }
            TextButton(onClick = onExitWithoutSave) {
                Text("直接退出")
            }
        },
    )
}

private fun saveFileContent(filePath: String, content: String) {
    val file = File(filePath)
    file.writeText(content)
}