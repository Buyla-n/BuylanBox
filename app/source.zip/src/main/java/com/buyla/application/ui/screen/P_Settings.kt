package com.buyla.application.ui.screen

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

object P_Settings {

    @OptIn(ExperimentalMaterial3Api::class)
    @Composable
    fun SettingsScreen() {
        // 状态变量
        var switch1State by remember { mutableStateOf(false) }
        var switch2State by remember { mutableStateOf(false) }
        var dropdownExpanded by remember { mutableStateOf(false) }
        var selectedOption by remember { mutableStateOf("选项1") }
        var textFieldValue by remember { mutableStateOf("") }

        Scaffold(
            topBar = {
                CenterAlignedTopAppBar(
                    title = {
                        Text(
                            text = "设置",
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(start = 8.dp),
                            style = MaterialTheme.typography.titleLarge
                        )
                    },
                )
            },
        ) { innerPadding ->
            Column(
                modifier = Modifier.padding(innerPadding),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Row {
                    Text(
                        text = "Switch_1",
                        modifier = Modifier.padding(horizontal = 16.dp)
                    )// 开关1
                    Switch(
                        checked = switch1State,
                        onCheckedChange = { switch1State = it },
                        modifier = Modifier.padding(horizontal = 16.dp)
                    )

                }

                Row(
                    modifier = Modifier
                ) {
                    Text(
                        text = "Switch_2",
                        modifier = Modifier.padding(horizontal = 16.dp)
                    )// 开关2
                    Switch(
                        checked = switch2State,
                        onCheckedChange = { switch2State = it },
                        modifier = Modifier.padding(horizontal = 16.dp)
                    )

                }

                // 下拉菜单
                ExposedDropdownMenuBox(
                    expanded = dropdownExpanded,
                    onExpandedChange = { dropdownExpanded = !dropdownExpanded },
                    modifier = Modifier.padding(horizontal = 16.dp)
                ) {
                    TextField(
                        value = selectedOption,
                        onValueChange = {},
                        readOnly = true,
                        trailingIcon = {
                            ExposedDropdownMenuDefaults.TrailingIcon(expanded = dropdownExpanded)
                        },
                        modifier = Modifier.fillMaxWidth()
                    )
                    ExposedDropdownMenu(
                        expanded = dropdownExpanded,
                        onDismissRequest = { dropdownExpanded = false }
                    ) {
                        listOf("选项1", "选项2", "选项3").forEach { option ->
                            DropdownMenuItem(
                                text = { Text(text = option) },
                                onClick = {
                                    selectedOption = option
                                    dropdownExpanded = false
                                }
                            )
                        }
                    }
                }

                // 输入框
                TextField(
                    value = textFieldValue,
                    onValueChange = { textFieldValue = it },
                    label = { Text("输入框") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp)
                )
            }
        }
    }
}