package com.buyla.application.ui.util

//import androidx.compose.ui.graphics.asImageBitmap
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.BitmapDrawable
import android.net.Uri
import android.provider.Settings
import android.widget.Toast
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.painter.BitmapPainter
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.vectorResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.buyla.application.EditActivity
import com.buyla.application.PictureActivity
import com.buyla.application.R
import com.buyla.application.VideoActivity
import java.io.File
import java.nio.file.Files
import java.nio.file.Path
import java.nio.file.StandardCopyOption

object FileUtil {
    @Composable
    fun getFileIconAndType(filePath: String): Pair<ImageVector, String> {
        val file = File(filePath)
        val type: String = when {
            file.isDirectory -> "folder"
            file.extension.equals("txt", ignoreCase = true) -> "txt"
            file.extension.equals("zip", ignoreCase = true) -> "zip"
            file.extension in listOf("jpg", "jpeg", "png", "webp") -> "image"
            file.extension.equals("mp4", ignoreCase = true) -> "video"
            file.extension in listOf("mp3", "wav", "m4a") -> "audio"
            file.extension.equals("xml", ignoreCase = true) -> "xml"
            file.extension.equals("apk", ignoreCase = true) -> "apk"
            else -> "null"
        }

        val icon: ImageVector = when (type) {
            "folder" -> ImageVector.vectorResource(id = R.drawable.baseline_folder_24)
            "txt" -> ImageVector.vectorResource(id = R.drawable.baseline_description_24)
            "zip" -> ImageVector.vectorResource(id = R.drawable.baseline_folder_zip_24)
            "image" -> ImageVector.vectorResource(id = R.drawable.baseline_photo_24)
            "video" -> ImageVector.vectorResource(id = R.drawable.baseline_video_file_24)
            "audio" -> ImageVector.vectorResource(id = R.drawable.baseline_audio_file_24)
            "xml" -> ImageVector.vectorResource(id = R.drawable.baseline_description_24)
            "apk" -> ImageVector.vectorResource(id = R.drawable.baseline_android_24)
            else -> ImageVector.vectorResource(id = R.drawable.baseline_insert_drive_file_24)
        }

        return icon to type
    }

    fun HandleFileClick(
        context: Context,
        filePath: Path,
        type: String,
        updatePath: (Path) -> Unit,
        ) {
        when (type) {
            "folder" -> {
                updatePath(filePath)
            }
            "txt" -> {
                openEditActivity(context, filePath.toString())
            }
            "image" -> {
                openPictureActivity(context, filePath.toString())
            }
            "video" -> {
                openVideoActivity(context, filePath.toString())
            }
            "audio" -> {
                openVideoActivity(context, filePath.toString())
            }
            "apk" -> {

            }
            else -> {
                //
            }
        }
    }

    fun installApk(context: Context, apkFile: Path) {
        val intent = Intent(Intent.ACTION_VIEW).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)

            val uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                File(apkFile.toString())
            )

            setDataAndType(uri, "application/vnd.android.package-archive")
        }
        if (!context.packageManager.canRequestPackageInstalls()) {
            // 跳转到允许安装未知来源应用的设置页面
            val intent = Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES).apply {
                data = Uri.parse("package:${context.packageName}")
            }
            context.startActivity(intent)
            return
        }

        try {
            context.startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(context, "未找到安装程序", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(context, "安装失败: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    fun openEditActivity(context: Context, filePath: String) {
        val intent = Intent(context, EditActivity::class.java).apply {
            putExtra("filePath", filePath)
        }
        context.startActivity(intent)
    }

    fun openPictureActivity(context: Context, filePath: String) {
        val intent = Intent(context, PictureActivity::class.java).apply {
            putExtra("filePath", filePath)
        }
        context.startActivity(intent)
    }

    fun openVideoActivity(context: Context, filePath: String) {
        val intent = Intent(context, VideoActivity::class.java).apply {
            putExtra("filePath", filePath)
        }
        context.startActivity(intent)
    }

    fun copyFile(source: Path, target: Path) {
        // 检查目标路径是否存在
        if (Files.exists(target)) {

            // 如果目标文件存在，尝试重命名目标文件
            val targetFileName = target.fileName.toString()
            val dotIndex = targetFileName.lastIndexOf('.')
            val baseName = if (dotIndex > 0) targetFileName.substring(0, dotIndex) else targetFileName
            val extension = if (dotIndex > 0) targetFileName.substring(dotIndex) else ""
            var targetIndex = 1
            var newTarget = target
            while (Files.exists(newTarget)) {
                val newFileName = "$baseName (${targetIndex})$extension"
                newTarget = target.parent.resolve(newFileName)
                targetIndex++
            }
            // 复制文件到新的目标路径
            try {
                Files.copy(source, newTarget, StandardCopyOption.REPLACE_EXISTING)
            } catch (e: Exception) {
                println("复制文件时发生错误: ${e.message}")
            }
        } else {
            // 如果目标文件不存在，直接复制
            try {
                Files.copy(source, target)
            } catch (e: Exception) {
                println("复制文件时发生错误: ${e.message}")
            }
        }
    }

    fun moveFile(
        source : Path,
        target : Path
    ){
        if (Files.exists(target)) {

            // 如果目标文件存在，尝试重命名目标文件
            val targetFileName = target.fileName.toString()
            val dotIndex = targetFileName.lastIndexOf('.')
            val baseName = if (dotIndex > 0) targetFileName.substring(0, dotIndex) else targetFileName
            val extension = if (dotIndex > 0) targetFileName.substring(dotIndex) else ""
            var targetIndex = 1
            var newTarget = target
            while (Files.exists(newTarget)) {
                val newFileName = "$baseName (${targetIndex})$extension"
                newTarget = target.parent.resolve(newFileName)
                targetIndex++
            }
            // 移动文件到新的目标路径
            try {
                Files.move(source, newTarget, StandardCopyOption.REPLACE_EXISTING)
            } catch (e: Exception) {
                println("移动文件时发生错误: ${e.message}")
            }
        } else {
            try {
                Files.move(source, target)
            } catch (e: Exception) {
                println("移动文件时发生错误: ${e.message}")
            }
        }
    }

    @OptIn(ExperimentalFoundationApi::class)
    @Composable
    fun fileList(
        Aicon: ImageVector,
        file: String,
        onClick: () -> Unit,
        type: String,
        filePath : Path,
        OppPath : Path,
        isLeft : Boolean
    ) {
        var showChooseDialog by remember { mutableStateOf(false) }
        var showOperateDialog by remember { mutableStateOf(false) }
        var showRenameDialog by remember { mutableStateOf(false) }
        var showInstallDialog by remember { mutableStateOf(false) }
        Row(
            modifier = Modifier
                .padding(horizontal = 16.dp, vertical = 8.dp)
                .fillMaxWidth()
                .height(48.dp)
                .background(
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    shape = RoundedCornerShape(8.dp)
                )
                .border(
                    width = 1.dp,
                    color = MaterialTheme.colorScheme.outline,
                    shape = RoundedCornerShape(8.dp)
                )
                .combinedClickable(
                    onClick = {
                        when (type) {
                            "null" -> showChooseDialog = true
                            "apk" -> showInstallDialog = true
                            else -> onClick()
                        }
                    },
                    onLongClick = { showOperateDialog = true }
                ),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Aicon,
                contentDescription = "File/Folder",
                modifier = Modifier.padding(start = 8.dp)
            )
            Text(
                text = file,
                modifier = Modifier.padding(horizontal = 16.dp),
                fontSize = 12.sp
            )
        }

        if (showChooseDialog) {
            val context = LocalContext.current
            var Choose: String = "null"
            AlertDialog(
                onDismissRequest = { showChooseDialog = false },
                title = { Text("打开方式") },
                text = {
                    Column {
                        Button(
                            modifier = Modifier
                                .padding(8.dp)
                                .fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            onClick = { Choose = "audio" }
                        ) {
                            Text("音频 / 视频")
                        }
                        Button(
                            modifier = Modifier
                                .padding(8.dp)
                                .fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            onClick = { Choose = "image" }
                        ) {
                            Text("图片")
                        }
                        Button(
                            modifier = Modifier
                                .padding(8.dp)
                                .fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            onClick = { Choose = "txt" }
                        ) {
                            Text("文本")
                        }
                        Button(
                            modifier = Modifier
                                .padding(8.dp)
                                .fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            onClick = { Choose = "apk" }
                        ) {
                            Text("安装包")
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        showChooseDialog = false
                        HandleFileClick(
                            context = context,
                            filePath = filePath,
                            type = Choose
                        ) {
                        }
                    }) {
                        Text("确定")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showChooseDialog = false }) {
                        Text("取消")
                    }
                }
            )
        }

        if (showOperateDialog){
            AlertDialog(
                onDismissRequest = { showOperateDialog = false },
                title = { Text("动作") },
                text = {
                    Column {
                        Button(
                            modifier = Modifier
                                .padding(8.dp)
                                .fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            onClick = {
                                showOperateDialog = false
                                showChooseDialog = true

                            }
                        ) {
                            Text("打开方式")
                        }
                        Button(
                            modifier = Modifier
                                .padding(8.dp)
                                .fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            onClick = {
                                showOperateDialog = false
                                showRenameDialog = true
                            }
                        ) {
                            Text("重命名")
                        }
                        Button(
                            modifier = Modifier
                                .padding(8.dp)
                                .fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            onClick = {
                                showOperateDialog = false
                                var targetPath = File(OppPath.toString() + File.separator + file)
                                copyFile(filePath, targetPath.toPath())
                            }
                        ) {
                            if (isLeft) {
                                Text("复制  ->")
                            } else {
                                Text("复制  <-")
                            }
                        }
                        Button(
                            modifier = Modifier
                                .padding(8.dp)
                                .fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            onClick = {
                                showOperateDialog = false
                                var targetPath = File(OppPath.toString() + File.separator + file)
                                moveFile(filePath, targetPath.toPath())
                            }
                        ) {
                            if (isLeft) {
                                Text("移动  ->")
                            } else {
                                Text("移动  <-")
                            }
                        }
                    }
                },
                confirmButton = {

                },
                dismissButton = {
                    TextButton(onClick = { showOperateDialog = false }) {
                        Text("取消")
                    }
                }
            )
        }

        if (showRenameDialog){
            var textFieldValue by remember { mutableStateOf(file) }
            AlertDialog(
                onDismissRequest = { showRenameDialog = false },
                title = { Text("动作") },
                text = {
                    Column {
                        TextField(
                            value = textFieldValue,
                            onValueChange = { textFieldValue = it },
                            label = { Text("输入框") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp)
                        )
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        showRenameDialog = false
                        val Ofile = File(filePath.toString())
                        val Nfile = File(filePath.parent.toString() + File.separator + textFieldValue)
                        Ofile.renameTo(Nfile)

                    }) {
                        Text("确定")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showRenameDialog = false }) {
                        Text("取消")
                    }
                }
            )
        }

        if (showInstallDialog) {
            val context = LocalContext.current
            AlertDialog(
                onDismissRequest = { showInstallDialog = false },
                title = { Text("安装包信息") },
                text = {
                    Column(
                        modifier = Modifier.padding(8.dp)
                    ) {
                        val apkInfo = getApkInfo(context, File(filePath.toString()))

                        Row(
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            apkInfo?.icon?.let { bitmap ->
                                Image(
                                    painter = BitmapPainter(bitmap),
                                    contentDescription = "应用图标",
                                    modifier = Modifier
                                        .size(42.dp)
                                        .clip(RoundedCornerShape(12.dp))
                                        .padding(bottom = 12.dp)
                                )
                            } ?: Box(
                                modifier = Modifier
                                    .size(42.dp)
                                    .padding(bottom = 12.dp)
                                    .background(
                                        color = MaterialTheme.colorScheme.surfaceVariant,
                                        shape = RoundedCornerShape(12.dp)
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = ImageVector.vectorResource(id = R.drawable.baseline_android_24),
                                    contentDescription = "默认图标",
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            apkInfo?.let {
                                // 基础信息行（图标+名称）
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.padding(bottom = 16.dp)
                                ) {
                                    // 显示应用图标

                                    // 名称和包名列
                                    Column(
                                        modifier = Modifier
                                            .padding(start = 16.dp)
                                            .weight(1f)
                                    ) {
                                        Text(
                                            text = it.appName,
                                            style = MaterialTheme.typography.titleMedium,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                        Text(
                                            text = it.packageName,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                            }
                        }

                        apkInfo?.let {

                            // 详细信息区块
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(
                                        color = MaterialTheme.colorScheme.surfaceVariant,
                                        shape = RoundedCornerShape(12.dp)
                                    )
                                    .padding(16.dp)
                            ) {
                                InfoRow("版本名称", it.versionName)
                                InfoRow("版本号", it.versionCode.toString())
                                InfoRow("安装状态", if (it.isInstalled) "已安装" else "未安装")
                            }
                        } ?: Text("无法读取APK信息", color = MaterialTheme.colorScheme.error)
                    }
                },
                confirmButton = {
                    Column {
                        Button(
                            modifier = Modifier
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                                .fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            onClick = { installApk(context, filePath) }
                        ) {
                            Text("安装")
                        }
                        Button(
                            modifier = Modifier
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                                .fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            onClick = { },
//                            colors = ButtonDefaults.buttonColors(
//                                containerColor = MaterialTheme.colorScheme.secondaryContainer // 设置按钮背景颜色
//                            )
                        ) {
                            Text("解开")
                        }
                        Button(
                            modifier = Modifier
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                                .fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            onClick = { showInstallDialog = false }
                        ) {
                            Text("取消")
                        }
                    }
                },
                dismissButton = {}
            )
        }
    }

    @Composable
    fun InfoRow(label: String, value: String) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                text = value,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurface
            )
        }
    }

    fun getApkInfo(context: Context, apkFile: File): ApkInfo? {
        return try {
            val pm = context.packageManager

            // 关键方法：解析APK文件
            val packageInfo = pm.getPackageArchiveInfo(
                apkFile.absolutePath,
                PackageManager.GET_ACTIVITIES
            ) ?: return null

            // 必须设置路径才能正确读取资源
            packageInfo.applicationInfo.sourceDir = apkFile.absolutePath
            packageInfo.applicationInfo.publicSourceDir = apkFile.absolutePath

            val icon = try {
                val drawable = pm.getApplicationIcon(packageInfo.applicationInfo)
                (drawable as BitmapDrawable).bitmap.asImageBitmap()
            } catch (e: Exception) {
                null
            }
            // 获取图标

            // 检查安装状态
            val isInstalled = try {
                pm.getPackageInfo(packageInfo.packageName, 0)
                true
            } catch (e: PackageManager.NameNotFoundException) {
                false
            }

            val appName = packageInfo.applicationInfo.loadLabel(pm).toString()
                .takeIf { it.isNotEmpty() }
                ?: packageInfo.packageName

            // 获取详细信息
            ApkInfo(
                packageName = packageInfo.packageName,
                versionCode = packageInfo.versionCode,
                versionName = packageInfo.versionName,
                appName = appName,
                icon = icon,
                isInstalled = isInstalled
            )
        } catch (e: Exception) {
            getFallbackInfo(apkFile) // 最终容错
        }
    }

    private fun getFallbackInfo(file: File): ApkInfo {
        return ApkInfo()
    }

    // 数据类
    data class ApkInfo(
        val packageName: String = "未知包名",
        val versionCode: Int = 0,
        val versionName: String = "未知版本",
        val appName: String = "未知应用",
        val icon: ImageBitmap? = null,
        val isInstalled: Boolean = false
    )

}
