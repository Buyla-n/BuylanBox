package com.buyla.application

import android.Manifest
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.res.vectorResource
import androidx.core.content.ContextCompat
import coil.compose.AsyncImage
import com.buyla.application.ui.theme.MyAppTheme
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import java.io.File

class PictureActivity : ComponentActivity() {
    private lateinit var filePath: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        window.isNavigationBarContrastEnforced = false

        // 获取传递过来的文件路径
        filePath = intent.getStringExtra("filePath") ?: run {
            finish() // 如果没有文件路径，直接关闭Activity
            return
        }

        val requestPermissionLauncher = registerForActivityResult(
            ActivityResultContracts.RequestPermission()
        ) { isGranted ->
            if (isGranted) {
                loadImageContent()
            } else {
                Toast.makeText(this, "需要存储权限才能打开文件", Toast.LENGTH_SHORT).show()
                finish()
            }
        }

        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.READ_EXTERNAL_STORAGE
            ) != android.content.pm.PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissionLauncher.launch(Manifest.permission.READ_EXTERNAL_STORAGE)
        } else {
            loadImageContent()
        }
    }

    private fun loadImageContent() {
        val file = File(filePath)
        if (file.exists()) {
            setContent {
                MyAppTheme {
                    ActivityContent(filePath)
                }
            }
        } else {
            Toast.makeText(this, "文件不存在！", Toast.LENGTH_SHORT).show()
            finish()
        }
    }

    @Composable
    @OptIn(ExperimentalMaterial3Api::class)
    fun ActivityContent(filePath: String) {
        Scaffold(
            topBar = {
                CenterAlignedTopAppBar(
                    title = { Text("查看图片") },
                    navigationIcon = {
                        IconButton(onClick = { finish() }) {
                            Icon(
                                imageVector = ImageVector.vectorResource(id = R.drawable.baseline_arrow_back_24),
                                contentDescription = "导航图标"
                            )
                        }
                    },
                    colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                        containerColor = MaterialTheme.colorScheme.background,
                    )
                )
            },
        ) { contentPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(contentPadding)
                    .background(MaterialTheme.colorScheme.background)
            ) {
                ZoomableImage(filePath = filePath)
            }
        }
    }

    @Composable
    fun ZoomableImage(filePath: String) {
        var scale by remember { mutableStateOf(1f) }
        var offsetX by remember { mutableStateOf(0f) }
        var offsetY by remember { mutableStateOf(0f) }

        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .pointerInput(Unit) {
                    coroutineScope {
                        detectTransformGestures { _, pan, zoom, _ ->
                            launch {
                                scale *= zoom
                                offsetX += pan.x
                                offsetY += pan.y
                            }
                        }
                    }
                }
        ) {
            AsyncImage(
                model = filePath,
                contentDescription = "图片内容",
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer(
                        scaleX = scale.coerceIn(0.5f, 10f), // 限制缩放范围
                        scaleY = scale.coerceIn(0.5f, 10f),
                        translationX = offsetX,
                        translationY = offsetY
                    )
            )
        }
    }
}