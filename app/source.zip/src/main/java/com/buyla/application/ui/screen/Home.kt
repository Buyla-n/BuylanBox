package com.buyla.application.ui.screen

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.buyla.application.SysProp

object Home {

    @OptIn(ExperimentalMaterial3Api::class)
    @SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
    @Composable
    fun HomeScreen(context: Context) {
        val folder = java.io.File("/sdcard/BuylaBox")
        if (!folder.exists()) {
            folder.mkdirs()
        }

        val infos = remember {
            listOf(
                InfoItem("提交建议", "将跳转入Coolapk"),
            )
        }
        Scaffold(
            topBar = {
                CenterAlignedTopAppBar(
                    title = { Text(text = "BuylaBox", modifier = Modifier.fillMaxWidth().padding(start = 8.dp),style = MaterialTheme.typography.titleLarge) },
                )
            },
        ) { innerPadding ->
            // 布局
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding),
                verticalArrangement = Arrangement.SpaceEvenly,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(8.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    Button(
                        onClick = { context.startActivity(Intent(context, SysProp::class.java)) },
                        modifier = Modifier
                            .size(150.dp) // 固定尺寸
                            .padding(8.dp),
                        shape = RoundedCornerShape(16.dp),
                    ) {
                        Text("系统属性")
                    }
                    Button(
                        onClick = { /* TODO: 按钮2逻辑 */ },
                        modifier = Modifier
                            .size(150.dp)
                            .padding(8.dp),
                        shape = RoundedCornerShape(16.dp),
                    ) {
                        Text("Button 2")
                    }
                }
                Row(
                    modifier = Modifier.fillMaxWidth().padding(8.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    Button(
                        onClick = { /* TODO: 按钮3逻辑 */ },
                        modifier = Modifier
                            .size(150.dp)
                            .padding(8.dp),
                        shape = RoundedCornerShape(16.dp),
                    ) {
                        Text("Button 3")
                    }
                    Button(
                        onClick = { /* TODO: 按钮4逻辑 */ },
                        modifier = Modifier
                            .size(150.dp)
                            .padding(8.dp),
                        shape = RoundedCornerShape(16.dp),
                    ) {
                        Text("Button 4")
                    }
                }
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(infos) { info ->
                        Home.InfoCard(info)
                    }
                }

            }
        }

    }

    fun openWebPage(context: Context) {
        val url = "https://www.coolapk.com/u/23065765"
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
        context.startActivity(intent)
    }

    data class InfoItem(
        val title: String,  // 信息标题
        val status: String, // 信息状态
    )

    @Composable
    fun InfoCard(info: Home.InfoItem) {
        val context = LocalContext.current
        ElevatedCard(
            modifier = Modifier.fillMaxWidth().clickable { openWebPage(context) }
        ) {
            Column(
                modifier = Modifier.padding(16.dp)
            ) {
                Text(
                    text = info.title,
                    style = MaterialTheme.typography.bodyLarge
                )
                Text(
                    text = info.status,
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }
    }
}