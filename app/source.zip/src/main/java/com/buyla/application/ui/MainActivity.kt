package com.buyla.application.ui

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.ExperimentalAnimationApi
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.with
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.vectorResource
import com.buyla.application.R
import com.buyla.application.ui.screen.Apps
import com.buyla.application.ui.screen.FileS
import com.buyla.application.ui.screen.Home
import com.buyla.application.ui.screen.Info
import com.buyla.application.ui.screen.P_Settings
import com.buyla.application.ui.theme.MyAppTheme
import java.io.File

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        window.isNavigationBarContrastEnforced = false
        setContent {
            MyAppTheme {
                mainApp(this@MainActivity)
            }
        }

        if (!hasFileManagementPermission()) {
            val intent = Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)
            startActivity(intent)
            return
        }

        val sdcardPath = Environment.getExternalStorageDirectory().getPath() + "/BuylaBox"
        val folder = File(sdcardPath)
        if (!folder.exists()) {
            folder.mkdirs()
        }
    }

    private fun hasFileManagementPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            Environment.isExternalStorageManager()
        } else {
            val result = checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE)
            result == PackageManager.PERMISSION_GRANTED
        }
    }

    @OptIn(ExperimentalAnimationApi::class)
    @Composable
    fun mainApp(context: Context) {
        var selectedItem by remember { mutableIntStateOf(0) }
        val items = listOf("主页", "信息", "文件", "活动", "设置")

        Scaffold(
            contentWindowInsets = WindowInsets(0, 0, 0, 0),
            bottomBar = {
                NavigationBar(
                ) {
                    items.forEachIndexed { index, item ->
                        NavigationBarItem(
                            selected = selectedItem == index,
                            onClick = { selectedItem = index },
                            icon = {
                                Icon(
                                    imageVector = when (index) {
                                        0 -> ImageVector.vectorResource(id = R.drawable.baseline_home_24)
                                        1 -> ImageVector.vectorResource(id = R.drawable.baseline_info_24)
                                        2 -> ImageVector.vectorResource(id = R.drawable.baseline_description_24)
                                        3 -> ImageVector.vectorResource(id = R.drawable.baseline_apps_24)
                                        else -> ImageVector.vectorResource(id = R.drawable.baseline_settings_24)
                                    },
                                    contentDescription = item
                                )
                            },
                            label = { Text(item) }
                        )
                    }
                }
            }
        ) { contentPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(contentPadding)
            ) {
                AnimatedContent(
                    targetState = selectedItem,
                    transitionSpec = {
                            fadeIn(animationSpec = tween(durationMillis = 150)) with
                            fadeOut(animationSpec = tween(durationMillis = 150))
                    }
                ) { target ->
                    when (target) {
                        0 -> { Home.HomeScreen(context = context) }
                        1 -> { Info.InfoScreen() }
                        2 -> { FileS.FileScreen(context = context) }
                        3 -> { Apps.AppScreen(context = context) }
                        4 -> { P_Settings.SettingsScreen() }
                    }
                }
            }
        }
    }
}