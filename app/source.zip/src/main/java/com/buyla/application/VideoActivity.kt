package com.buyla.application

import android.Manifest
import android.net.Uri
import android.os.Bundle
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.vectorResource
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.buyla.application.ui.theme.MyAppTheme
import java.io.File

class VideoActivity : ComponentActivity() {
    private lateinit var filePath: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        enableEdgeToEdge()
        window.isNavigationBarContrastEnforced = false

        // 获取传递过来的文件路径
        filePath = intent.getStringExtra("filePath") ?: run {
            finish() // 如果没有文件路径，直接关闭Activity
            return
        }

        val requestPermissionLauncher = registerForActivityResult(
            ActivityResultContracts.RequestPermission()
        ) { isGranted ->
            if (isGranted) {
                loadVideoContent()
            } else {
                Toast.makeText(this, "需要存储权限才能打开文件", Toast.LENGTH_SHORT).show()
                finish()
            }
        }

        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.READ_EXTERNAL_STORAGE
            ) != android.content.pm.PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissionLauncher.launch(Manifest.permission.READ_EXTERNAL_STORAGE)
        } else {
            loadVideoContent()
        }
    }

    private fun loadVideoContent() {
        val file = File(filePath)
        if (file.exists()) {
            setContent {
                MyAppTheme {
                    ActivityContent(filePath)
                }
            }
        } else {
            Toast.makeText(this, "文件不存在！", Toast.LENGTH_SHORT).show()
            finish()
        }
    }

    @Composable
    @OptIn(ExperimentalMaterial3Api::class)
    fun ActivityContent(filePath: String) {
        Scaffold(
            topBar = {
                CenterAlignedTopAppBar(
                    title = { Text("视频播放器") },
                    navigationIcon = {
                        IconButton(onClick = { finish() }) {
                            Icon(
                                imageVector = ImageVector.vectorResource(id = R.drawable.baseline_arrow_back_24),
                                contentDescription = "返回"
                            )
                        }
                    },
                    colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                        containerColor = MaterialTheme.colorScheme.background,
                    )
                )
            },
        ) { contentPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(contentPadding)
                    .background(MaterialTheme.colorScheme.background)
            ) {
                VideoPlayer(filePath = filePath)
            }
        }
    }

    @androidx.annotation.OptIn(UnstableApi::class)
    @Composable
    fun VideoPlayer(filePath: String) {
        val context = LocalContext.current

        // 将文件路径转换为 Uri（处理不同路径格式）
        val uri = remember(filePath) {
            when {
                filePath.startsWith("http://") ||
                        filePath.startsWith("https://") ||
                        filePath.startsWith("content://") -> Uri.parse(filePath)
                else -> Uri.fromFile(File(filePath))
            }
        }

        // 创建并配置 ExoPlayer 实例
        val exoPlayer = remember(filePath) {
            ExoPlayer.Builder(context).build().apply {
                setMediaItem(MediaItem.fromUri(uri))
                prepare()
                playWhenReady = true // 自动开始播放
                repeatMode = ExoPlayer.REPEAT_MODE_OFF // 设置循环模式
            }
        }

        // 生命周期管理：在组件销毁时释放播放器
        DisposableEffect(exoPlayer) {
            onDispose {
                exoPlayer.release()
            }
        }

        // 将播放器绑定到视图
        AndroidView(
            factory = { ctx ->
                PlayerView(ctx).apply {
                    layoutParams = FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                    player = exoPlayer
                    useController = true // 显示默认控制界面
                    resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT // 视频缩放模式
                }
            },
            modifier = Modifier.fillMaxSize()
        )
    }
}
